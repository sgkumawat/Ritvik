-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 16, 2019 at 08:36 AM
-- Server version: 5.7.21
-- PHP Version: 7.0.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ongroup`
--

-- --------------------------------------------------------

--
-- Table structure for table `network_access`
--

DROP TABLE IF EXISTS `network_access`;
CREATE TABLE IF NOT EXISTS `network_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `controller` varchar(200) DEFAULT NULL,
  `action` varchar(200) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `only_for_content_access` int(2) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `network_access`
--

INSERT INTO `network_access` (`id`, `name`, `controller`, `action`, `slug`, `only_for_content_access`, `status`) VALUES
(1, 'My Page', 'Themes', 'mypage', 'mypage', 0, 1),
(2, 'Friend List', 'Themes', 'friendList', 'friend-list', 0, 1),
(3, 'Activity Feed', 'Themes', 'activityFeed', 'activity-feed', 0, 1),
(4, 'Posts', 'Themes', 'postdetail', 'post-detail', 0, 1),
(5, 'Photos', 'Themes', 'photos', 'photos', 0, 1),
(6, 'Audios', 'Themes', 'audios', 'audios', 0, 1),
(7, 'Videos\r\n', 'Themes', 'videos\r\n', 'videos\r\n', 0, 1),
(8, 'Groups\r\n', 'Themes', 'groups\r\n', 'groups\r\n', 0, 1),
(9, 'Forum\r\n', 'Themes', 'forum\r\n', 'forum\r\n', 0, 1),
(10, 'Articles\r\n', 'Themes', 'articles\r\n', 'articles\r\n', 0, 1),
(11, 'Events\r\n', 'Themes', 'events\r\n', 'events\r\n', 0, 1),
(12, 'Poll\r\n', 'Themes', 'poll\r\n', 'poll\r\n', 0, 1),
(13, 'My Photos\r\n', 'Themes', 'myPhotos\r\n', 'my-photos\r\n', 0, 1),
(14, 'Comment Wall\r\n', 'Themes', 'commentWall\r\n', 'comment-wall\r\n', 0, 1),
(15, 'My Discussions\r\n', 'Themes', 'myDiscussions\r\n', 'my-discussions\r\n', 0, 1),
(16, 'My Profile\r\n', 'Themes', 'myProfile\r\n', 'my-profile\r\n', 0, 1),
(17, 'My Blog\r\n', 'Themes', 'myBlog\r\n', 'my-blog\r\n', 0, 1),
(18, 'My Friend Requests\r\n', 'Themes', 'myFriendRequests\r\n', 'my-friend-requests\r\n', 0, 1),
(19, 'Chat\r\n', 'Themes', 'chat\r\n', 'chat\r\n', 0, 1),
(20, 'General Settings\r\n', 'Themes', 'generalSettings\r\n', 'general-settings\r\n', 0, 1),
(21, 'Broadcast\r\n', 'Themes', 'broadcast\r\n', 'broadcast\r\n', 0, 1),
(22, 'Faq\r\n', 'Themes', 'faqs\r\n', 'faqs\r\n', 0, 1),
(23, 'Help Center\r\n', 'Themes', 'helpCenter\r\n', 'help-center\r\n', 0, 1),
(24, 'Site Report\r\n', 'Themes', 'siteReport\r\n', 'site-report\r\n', 0, 1),
(25, 'Photo Details\r\n', 'Themes', 'photoDetails\r\n', 'photo-details\r\n', 0, 1),
(26, 'Audio Details\r\n', 'Themes', 'audioDetails\r\n', 'audio-details', 0, 1),
(27, 'Video Details\r\n', 'Themes', 'videoDetails\r\n', 'video-details\r\n', 0, 1),
(28, 'Add Group\r\n', 'Themes', 'addgroup\r\n', 'addgroup\r\n', 0, 1),
(29, 'Group Detail\r\n', 'Themes', 'groupDetail\r\n', 'group-detail\r\n', 0, 1),
(30, 'Disccusion Detail\r\n', 'Themes', 'disccusionDetail\r\n', 'disccusion-detail\r\n', 0, 1),
(31, 'Group Photo Detail\r\n', 'Themes', 'groupPhotoDetail\r\n', 'group-photo-detail\r\n', 0, 1),
(32, 'Forum Detail\r\n', 'Themes', 'forumDetail\r\n', 'forum-detail\r\n', 0, 1),
(33, 'Article Detail\r\n', 'Themes', 'articleDetails\r\n', 'article-details\r\n', 0, 1),
(34, 'Event Detail\r\n', 'Themes', 'eventDetails\r\n', 'event-details\r\n', 0, 1),
(35, 'Poll Detail\r\n', 'Themes', 'pollDetails\r\n', 'poll-details\r\n', 0, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
